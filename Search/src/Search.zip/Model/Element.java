/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author ADMIN
 */
public class Element {

    private int size_array;
    private int[] array;

    /**
     * @return the size_array
     */
    public int getSize_array() {
        return size_array;
    }

    /**
     * @param size_array the size_array to set
     */
    public void setSize_array(int size_array) {
        this.size_array = size_array;
    }

    /**
     * @return the array
     */
    public int[] getArray() {
        return array;
    }

    /**
     * @param array the array to set
     */
    public void setArray(int[] array) {
        this.array = array;
    }
}
